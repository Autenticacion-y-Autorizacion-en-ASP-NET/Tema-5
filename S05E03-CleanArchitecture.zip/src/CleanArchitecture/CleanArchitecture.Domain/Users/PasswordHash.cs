namespace CleanArchitecture.Domain.Users;

public record PasswordHash(string Value);